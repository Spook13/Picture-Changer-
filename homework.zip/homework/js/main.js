// ash
function makeAsh() {
    document.getElementById("theImage"). src="imgs/ash.png";
    // showing
    document.getElementById("ashPara").style.display = "block";
    // not showing
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// banshee
function makeBanshee() {
    document.getElementById("theImage"). src="imgs/banshee.png";
    // showing
    document.getElementById("bansheePara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// ember
function makeEmber() {
    document.getElementById("theImage"). src="imgs/ember.png";
    // showing
    document.getElementById("emberPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// excalibur
function makeExcalibur() {
    document.getElementById("theImage"). src="imgs/excalibur.png";
    // showing
    document.getElementById("excaliburPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// frost
function makeFrost() {
    document.getElementById("theImage"). src="imgs/frost.png";
    // showing
    document.getElementById("frostPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// gauss
function makeGauss() {
    document.getElementById("theImage"). src="imgs/gauss.png";
    // showing
    document.getElementById("gaussPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// grendel
function makeGrendel() {
    document.getElementById("theImage"). src="imgs/grendel.png";
    // showing
    document.getElementById("grendelPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// ivara
function makeIvara() {
    document.getElementById("theImage"). src="imgs/ivara.png";
    // showing
    document.getElementById("ivaraPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// loki
function makeLoki() {
    document.getElementById("theImage"). src="imgs/loki.png";
    // showing
    document.getElementById("lokiPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// mag
function makeMag() {
    document.getElementById("theImage"). src="imgs/mag.png";
    // showing
    document.getElementById("magPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// nekros
function makeNekros() {
    document.getElementById("theImage"). src="imgs/nekros.png";
    // showing
    document.getElementById("nekrosPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// nova
function makeNova() {
    document.getElementById("theImage"). src="imgs/nova.png";
    // showing
    document.getElementById("novaPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// nyx
function makeNyx() {
    document.getElementById("theImage"). src="imgs/nyx.png";
    // showing
    document.getElementById("nyxPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// rhino
function makeRhino() {
    document.getElementById("theImage"). src="imgs/rhino.png";
    // showing
    document.getElementById("rhinoPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// saryn
function makeSaryn() {
    document.getElementById("theImage"). src="imgs/saryn.png";
    // showing
    document.getElementById("sarynPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// trinity
function makeTrinity() {
    document.getElementById("theImage"). src="imgs/trinity.png";
    // showing
    document.getElementById("trinityPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// umbra
function makeUmbra() {
    document.getElementById("theImage"). src="imgs/umbra.png";
    // showing
    document.getElementById("umbraPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// valkyr
function makeValkyr() {
    document.getElementById("theImage"). src="imgs/valkyr.png";
    // showing
    document.getElementById("valkyrPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}

// vauban
function makeVauban() {
    document.getElementById("theImage"). src="imgs/vauban.png";
    // showing
    document.getElementById("vaubanPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("voltPara").style.display = "none";
}
// volt
function makeVolt() {
    document.getElementById("theImage"). src="imgs/volt.png";
    // showing
    document.getElementById("voltPara").style.display = "block";
    // not showing
    document.getElementById("ashPara").style.display = "none";
    document.getElementById("bansheePara").style.display = "none";
    document.getElementById("emberPara").style.display = "none";
    document.getElementById("excaliburPara").style.display = "none";
    document.getElementById("frostPara").style.display = "none";
    document.getElementById("gaussPara").style.display = "none";
    document.getElementById("grendelPara").style.display = "none";
    document.getElementById("ivaraPara").style.display = "none";
    document.getElementById("lokiPara").style.display = "none";
    document.getElementById("magPara").style.display = "none";
    document.getElementById("nekrosPara").style.display = "none";
    document.getElementById("novaPara").style.display = "none";
    document.getElementById("nyxPara").style.display = "none";
    document.getElementById("rhinoPara").style.display = "none";
    document.getElementById("sarynPara").style.display = "none";
    document.getElementById("trinityPara").style.display = "none";
    document.getElementById("umbraPara").style.display = "none";
    document.getElementById("valkyrPara").style.display = "none";
    document.getElementById("vaubanPara").style.display = "none";
}

